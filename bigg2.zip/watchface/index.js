﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_distance_icon_img = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_calorie_icon_img = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_current_separator_img = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_digital_clock_minute_separator_img = ''
        let normal_image_img = ''
        let normal_wind_direction_image_progress_img_level = ''
        let normal_wind_text_text_img = ''
        let normal_wind_text_separator_img = ''
        let normal_battery_icon_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_moon_image_progress_img_level = ''
        let normal_altimeter_text_text_img = ''
        let normal_altimeter_text_separator_img = ''
        let normal_sun_high_text_img = ''
        let normal_sun_high_separator_img = ''
        let normal_sun_low_text_img = ''
        let normal_sun_low_separator_img = ''
        let normal_humidity_text_text_img = ''
        let normal_humidity_text_separator_img = ''
        let normal_city_name_text = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_date_img_date_month_img = ''
        let normal_day_TextRotate = new Array(2);
        let normal_day_TextRotate_ASCIIARRAY = new Array(10);
        let normal_day_TextRotate_img_width = 20;
        let normal_day_TextRotate_unit = null;
        let normal_day_TextRotate_unit_width = 50;
        let normal_day_TextRotate_error_img_width = 50;
        let normal_timerTextUpdate = undefined;
        let normal_date_img_date_week_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_text_separator_img = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sleep_jumpable_img_click = ''
        let timeSensor = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'cap_2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 148,
              y: 126,
              src: 'stat_B_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 15,
              y: 7,
              src: 'SIG_VKL.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 262,
              y: 263,
              src: 'ic_activ_7.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 307,
              y: 268,
              font_array: ["S_0.png","S_1.png","S_2.png","S_3.png","S_4.png","S_5.png","S_6.png","S_7.png","S_8.png","S_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'clean.png',
              unit_tc: 'clean.png',
              unit_en: 'clean.png',
              imperial_unit_sc: 'clean.png',
              imperial_unit_tc: 'clean.png',
              imperial_unit_en: 'clean.png',
              dot_image: 'S_dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'clean.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 262,
              y: 295,
              src: 'ic_activ_10.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 303,
              y: 303,
              font_array: ["S_0.png","S_1.png","S_2.png","S_3.png","S_4.png","S_5.png","S_6.png","S_7.png","S_8.png","S_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'clean.png',
              unit_tc: 'clean.png',
              unit_en: 'clean.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'clean.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 75,
              hour_startY: 156,
              hour_array: ["H_0.png","H_1.png","H_2.png","H_3.png","H_4.png","H_5.png","H_6.png","H_7.png","H_8.png","H_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'clean.png',
              hour_unit_tc: 'clean.png',
              hour_unit_en: 'clean.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 271,
              minute_startY: 160,
              minute_array: ["M_0.png","M_1.png","M_2.png","M_3.png","M_4.png","M_5.png","M_6.png","M_7.png","M_8.png","M_9.png"],
              minute_zero: 1,
              minute_space: 4,
              minute_angle: 0,
              minute_follow: 0,
              minute_unit_sc: 'clean.png',
              minute_unit_tc: 'clean.png',
              minute_unit_en: 'clean.png',
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'clean.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'clean.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'Zaplatka2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_direction_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 164,
              y: 341,
              image_array: ["wind_st_0.png","wind_st_1.png","wind_st_2.png","wind_st_3.png","wind_st_4.png","wind_st_5.png","wind_st_6.png","wind_st_7.png"],
              image_length: 8,
              type: hmUI.data_type.WIND_DIRECTION,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 277,
              y: 343,
              font_array: ["S_0.png","S_1.png","S_2.png","S_3.png","S_4.png","S_5.png","S_6.png","S_7.png","S_8.png","S_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'clean.png',
              unit_tc: 'clean.png',
              unit_en: 'clean.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'clean.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 123,
              y: 433,
              src: 'dig_b_pr.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 91,
              y: 411,
              font_array: ["dig_b_0.png","dig_b_1.png","dig_b_2.png","dig_b_3.png","dig_b_4.png","dig_b_5.png","dig_b_6.png","dig_b_7.png","dig_b_8.png","dig_b_9.png"],
              padding: false,
              h_space: 0,
              angle: 31,
              unit_sc: 'clean.png',
              unit_tc: 'clean.png',
              unit_en: 'clean.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'clean.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 6,
              y: 276,
              image_array: ["10.png","20.png","30.png","40.png","50.png","60.png","70.png","80.png","90.png","100.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 328,
              y: 60,
              image_array: ["moon_01.png","moon_02.png","moon_03.png","moon_04.png","moon_05.png","moon_06.png","moon_07.png","moon_08.png","moon_09.png","moon_10.png","moon_11.png","moon_12.png","moon_13.png","moon_14.png","moon_15.png","moon_16.png","moon_17.png","moon_18.png","moon_19.png","moon_20.png","moon_21.png","moon_22.png","moon_23.png","moon_24.png","moon_25.png","moon_26.png","moon_27.png","moon_28.png","moon_29.png","moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 377,
              y: 106,
              font_array: ["S_0.png","S_1.png","S_2.png","S_3.png","S_4.png","S_5.png","S_6.png","S_7.png","S_8.png","S_9.png"],
              padding: false,
              h_space: 0,
              angle: 57,
              unit_sc: 'clean.png',
              unit_tc: 'clean.png',
              unit_en: 'clean.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'clean.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 382,
              y: 347,
              font_array: ["dig_d_0.png","dig_d_1.png","dig_d_2.png","dig_d_3.png","dig_d_4.png","dig_d_5.png","dig_d_6.png","dig_d_7.png","dig_d_8.png","dig_d_9.png"],
              padding: false,
              h_space: 0,
              angle: -57,
              unit_sc: 'clean.png',
              unit_tc: 'clean.png',
              unit_en: 'clean.png',
              invalid_image: 'clean.png',
              dot_image: 'dig_d_dot2.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'clean.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 418,
              y: 271,
              font_array: ["dig_d_0.png","dig_d_1.png","dig_d_2.png","dig_d_3.png","dig_d_4.png","dig_d_5.png","dig_d_6.png","dig_d_7.png","dig_d_8.png","dig_d_9.png"],
              padding: false,
              h_space: 0,
              angle: -83,
              unit_sc: 'clean.png',
              unit_tc: 'clean.png',
              unit_en: 'clean.png',
              invalid_image: 'clean.png',
              dot_image: 'dig_d_dot2.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'clean.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 34,
              y: 229,
              font_array: ["S_0.png","S_1.png","S_2.png","S_3.png","S_4.png","S_5.png","S_6.png","S_7.png","S_8.png","S_9.png"],
              padding: false,
              h_space: 0,
              angle: -86,
              unit_sc: 'clean.png',
              unit_tc: 'clean.png',
              unit_en: 'clean.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'clean.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 165,
              y: 86,
              w: 150,
              h: 30,
              text_size: 20,
              char_space: 0,
              line_space: 0,
              color: 0xFF9AA99B,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["ww_0.png","ww_1.png","ww_2.png","ww_3.png","ww_4.png","ww_5.png","ww_6.png","ww_7.png","ww_8.png","ww_9.png","ww_10.png","ww_11.png","ww_12.png","ww_13.png","ww_14.png","ww_15.png","ww_16.png","ww_17.png","ww_18.png","ww_19.png","ww_20.png","ww_21.png","ww_22.png","ww_23.png","ww_24.png","ww_25.png","ww_26.png","ww_27.png","ww_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 78,
              y: 105,
              font_array: ["S_0.png","S_1.png","S_2.png","S_3.png","S_4.png","S_5.png","S_6.png","S_7.png","S_8.png","S_9.png"],
              padding: false,
              h_space: 0,
              angle: -49,
              negative_image: 'S_minus.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 92,
              month_startY: 362,
              month_sc_array: ["mo_0.png","mo_1.png","mo_2.png","mo_3.png","mo_4.png","mo_5.png","mo_6.png","mo_7.png","mo_8.png","mo_9.png","mo_10.png","mo_11.png"],
              month_tc_array: ["mo_0.png","mo_1.png","mo_2.png","mo_3.png","mo_4.png","mo_5.png","mo_6.png","mo_7.png","mo_8.png","mo_9.png","mo_10.png","mo_11.png"],
              month_en_array: ["mo_0.png","mo_1.png","mo_2.png","mo_3.png","mo_4.png","mo_5.png","mo_6.png","mo_7.png","mo_8.png","mo_9.png","mo_10.png","mo_11.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_day_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 92,
              // y: 341,
              // font_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 57,
              // unit_en: 'clean.png',
              // invalid_image: 'clean.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.DAY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_day_TextRotate_ASCIIARRAY[0] = 'data_0.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[1] = 'data_1.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[2] = 'data_2.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[3] = 'data_3.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[4] = 'data_4.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[5] = 'data_5.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[6] = 'data_6.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[7] = 'data_7.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[8] = 'data_8.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[9] = 'data_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_day_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 92,
                center_y: 341,
                pos_x: 92,
                pos_y: 341,
                angle: 57,
                src: 'data_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_day_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_day_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 92,
              center_y: 341,
              pos_x: 92,
              pos_y: 341,
              angle: 57,
              src: 'clean.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_day_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            let screenType = hmSetting.getScreenType();
            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 35,
              y: 258,
              week_en: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              week_tc: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              week_sc: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 326,
              y: 393,
              font_array: ["S_0.png","S_1.png","S_2.png","S_3.png","S_4.png","S_5.png","S_6.png","S_7.png","S_8.png","S_9.png"],
              padding: false,
              h_space: 0,
              angle: -32,
              unit_sc: 'clean.png',
              unit_tc: 'clean.png',
              unit_en: 'clean.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'clean.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 210,
              y: 420,
              font_array: ["S_0.png","S_1.png","S_2.png","S_3.png","S_4.png","S_5.png","S_6.png","S_7.png","S_8.png","S_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'clean.png',
              unit_tc: 'clean.png',
              unit_en: 'clean.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'clean.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'sec_03png.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 25,
              second_posY: 245,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'cap_1a111.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 75,
              hour_startY: 156,
              hour_array: ["H_0.png","H_1.png","H_2.png","H_3.png","H_4.png","H_5.png","H_6.png","H_7.png","H_8.png","H_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'clean.png',
              hour_unit_tc: 'clean.png',
              hour_unit_en: 'clean.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 271,
              minute_startY: 158,
              minute_array: ["M_0.png","M_1.png","M_2.png","M_3.png","M_4.png","M_5.png","M_6.png","M_7.png","M_8.png","M_9.png"],
              minute_zero: 1,
              minute_space: 4,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'clean.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 221,
              y: 451,
              font_array: ["dig_b_0.png","dig_b_1.png","dig_b_2.png","dig_b_3.png","dig_b_4.png","dig_b_5.png","dig_b_6.png","dig_b_7.png","dig_b_8.png","dig_b_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'clean.png',
              unit_tc: 'clean.png',
              unit_en: 'clean.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'clean.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 200,
              y: 401,
              w: 82,
              h: 70,
              src: 'clean.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 310,
              y: 363,
              w: 76,
              h: 61,
              src: 'clean.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 123,
              y: 202,
              w: 100,
              h: 100,
              src: 'clean.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 242,
              y: 106,
              w: 94,
              h: 57,
              src: 'clean.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sleep_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 394,
              y: 249,
              w: 56,
              h: 100,
              src: 'clean.png',
              type: hmUI.data_type.SLEEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            //start of ignored block
            function text_update() {
              console.log('text_update()');

              console.log('update text rotate day_TIME');
              let valueDay = timeSensor.day;
              let normal_day_rotate_string = parseInt(valueDay).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_day_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_day_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (valueDay != null && valueDay != undefined && isFinite(valueDay) && normal_day_rotate_string.length > 0 && normal_day_rotate_string.length <= 2) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_day_TextRotate_posOffset = normal_day_TextRotate_img_width * normal_day_rotate_string.length;
                  img_offset -= normal_day_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_day_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_day_TextRotate[index].setProperty(hmUI.prop.POS_X, 92 + img_offset);
                      normal_day_TextRotate[index].setProperty(hmUI.prop.SRC, normal_day_TextRotate_ASCIIARRAY[charCode]);
                      normal_day_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_day_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  normal_day_TextRotate_unit.setProperty(hmUI.prop.POS_X, 92 + img_offset);
                  normal_day_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  normal_day_TextRotate[0].setProperty(hmUI.prop.POS_X, 92 - normal_day_TextRotate_error_img_width / 2);
                  normal_day_TextRotate[0].setProperty(hmUI.prop.SRC, 'clean.png');
                  normal_day_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

            };

            //end of ignored block
            function scale_call() {
              console.log('scale_call()');

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                text_update();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTextUpdate) {
                    normal_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTextUpdate) {
                  timer.stopTimer(normal_timerTextUpdate);
                  normal_timerTextUpdate = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}